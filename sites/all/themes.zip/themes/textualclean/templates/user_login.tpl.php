<form action="/magisterio/ajax_register/login/ajax" method="post" id="user-login" accept-charset="UTF-8" class="ctools-use-modal-processed">
<div>
	<div class="my-form-wrapper">  		
		<div class="form-item form-type-textfield form-item-name">  			
			<input type="text" id="edit-name" name="name" value="" size="60" maxlength="60" class="form-text required" placeholder="usuario">
			
		</div>
		<div class="form-item form-type-password form-item-pass">  			
 			<input type="password" id="edit-pass" name="pass" size="60" maxlength="128" class="form-text required" placeholder="clave">			
		</div>
		<input type="hidden" name="form_build_id" value="form-OnNJ36eY5zJGH1cuzF4OcdM2uEA06aFNnA2jlSPiXi0">
		<input type="hidden" name="form_id" value="user_login">
		<div class="form-actions form-wrapper" id="edit-actions--11"><input type="submit" id="edit-submit--3" name="op" value="entrar" class="form-submit">
			<div class="ajax-register-links-wrapper">
			  		<div class="item-list">
				  		<ul class="ajax-register-links inline">
				  			<li class="first">
				  				<a href="/magisterio/registro" class="ctools-use-modal ctools-modal-ctools-ajax-register-style ctools-use-modal-processed" rel="nofollow" title="Crear nueva cuenta">REGÍSTRATE</a> | 
				  			</li>
							<li class="last">
								<a href="/magisterio/ajax_register/password/nojs" class="ctools-use-modal ctools-modal-ctools-ajax-register-style ctools-use-modal-processed" rel="nofollow" title="Solicitar una nueva contraseña">RECUPERA TU CLAVE</a>
							</li>
						</ul>
					</div>
				</div>
		</div>
	</div>
</div>

</form>